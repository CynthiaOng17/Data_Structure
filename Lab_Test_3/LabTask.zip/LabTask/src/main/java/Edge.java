/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */

class Edge<T extends Comparable<T>, N extends Comparable<N>> {
    Task<T, N> toVertex;
    N weight;
    Edge<T, N> nextEdge;

    public Edge(Task<T, N> toVertex, N weight, Edge<T, N> nextEdge) {
        this.toVertex = toVertex;
        this.weight = weight;
        this.nextEdge = nextEdge;
    }
}