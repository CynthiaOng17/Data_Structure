/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
class Task<T extends Comparable<T>, N extends Comparable<N>> {
    T vertexInfo;
    int indeg;
    int outdeg;
    Task<T, N> nextVertex;
    Edge<T, N> firstEdge;
    int estimatedRunTime;

    public Task() {
        vertexInfo = null;
        indeg = 0;
        outdeg = 0;
        nextVertex = null;
        firstEdge = null;
        estimatedRunTime = 0;
    }

    public Task(T vInfo, Task<T, N> next) {
        vertexInfo = vInfo;
        indeg = 0;
        outdeg = 0;
        nextVertex = next;
        firstEdge = null;
        estimatedRunTime = 0;
    }

    public int getEstimatedRunTime() {
        return estimatedRunTime;
    }

    public void setEstimatedRunTime(int estimatedRunTime) {
        this.estimatedRunTime = estimatedRunTime;
    }

    @Override
    public String toString() {
        return "Task{" +
                "vertexInfo=" + vertexInfo +
                ", estimatedRunTime=" + estimatedRunTime +
                '}';
    }
}




