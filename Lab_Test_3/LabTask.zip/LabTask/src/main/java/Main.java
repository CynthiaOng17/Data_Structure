
import java.io.IOException;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Main {
    public static void main(String[] args) {
        

        String dagFile = "\"C:\\Users\\User\\Downloads\\input.dag\"";

        try {
            WorkflowGraph graph = new WorkflowGraph();
            graph.readDAGFile(dagFile);
            graph.printTasksSortedByEstimatedRunTime();

            // Find and print the critical path
            List<Task<String, Integer>> criticalPath = graph.findCriticalPath();
            System.out.println("Critical Path:");
            for (Task<String, Integer> task : criticalPath) {
                System.out.println(task.vertexInfo);
            }

            // Print total run time of the critical path
            int totalRunTime = criticalPath.stream().mapToInt(Task::getEstimatedRunTime).sum();
            System.out.println("Total Run Time: " + totalRunTime + " minutes");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
