

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
import java.io.*;
import java.util.*;
public class WorkflowGraph {
    private Task<String, Integer> head;
    private int size;
    private Map<String, Task<String, Integer>> tasks;

    public WorkflowGraph() {
        head = null;
        size = 0;
        tasks = new HashMap<>();
    }

    public void clear() {
        head = null;
    }

    public int getSize() {
        return this.size;
    }

    public int getIndeg(String v) {
        if (hasVertex(v)) {
            Task<String, Integer> temp = head;
            while (temp != null) {
                if (temp.vertexInfo.equals(v))
                    return temp.indeg;
                temp = temp.nextVertex;
            }
        }
        return -1;
    }

    public int getOutdeg(String v) {
        if (hasVertex(v)) {
            Task<String, Integer> temp = head;
            while (temp != null) {
                if (temp.vertexInfo.equals(v))
                    return temp.outdeg;
                temp = temp.nextVertex;
            }
        }
        return -1;
    }

    public boolean hasVertex(String v) {
        if (head == null)
            return false;
        Task<String, Integer> temp = head;
        while (temp != null) {
            if (temp.vertexInfo.equals(v))
                return true;
            temp = temp.nextVertex;
        }
        return false;
    }

    public boolean addVertex(String v) {
        if (!hasVertex(v)) {
            Task<String, Integer> temp = head;
            Task<String, Integer> newVertex = new Task<>(v, null);
            if (head == null)
                head = newVertex;
            else {
                Task<String, Integer> previous = head;
                while (temp != null) {
                    previous = temp;
                    temp = temp.nextVertex;
                }
                previous.nextVertex = newVertex;
            }
            size++;
            return true;
        } else
            return false;
    }

    public int getIndex(String v) {
        Task<String, Integer> temp = head;
        int pos = 0;
        while (temp != null) {
            if (temp.vertexInfo.equals(v))
                return pos;
            temp = temp.nextVertex;
            pos += 1;
        }
        return -1;
    }

    public ArrayList<String> getAllVertexObjects() {
        ArrayList<String> list = new ArrayList<>();
        Task<String, Integer> temp = head;
        while (temp != null) {
            list.add(temp.vertexInfo);
            temp = temp.nextVertex;
        }
        return list;
    }

    public ArrayList<Task<String, Integer>> getAllVertices() {
        ArrayList<Task<String, Integer>> list = new ArrayList<>();
        Task<String, Integer> temp = head;
        while (temp != null) {
            list.add(temp);
            temp = temp.nextVertex;
        }
        return list;
    }

    public String getVertex(int pos) {
        if (pos > size - 1 || pos < 0)
            return null;
        Task<String, Integer> temp = head;
        for (int i = 0; i < pos; i++)
            temp = temp.nextVertex;
        return temp.vertexInfo;
    }

    public boolean addEdge(String source, String destination, Integer w) {
        if (head == null)
            return false;
        if (!hasVertex(source) || !hasVertex(destination))
            return false;
        Task<String, Integer> sourceVertex = head;
        while (sourceVertex != null) {
            if (sourceVertex.vertexInfo.equals(source)) {
                Task<String, Integer> destinationVertex = head;
                while (destinationVertex != null) {
                    if (destinationVertex.vertexInfo.equals(destination)) {
                        Edge<String, Integer> currentEdge = sourceVertex.firstEdge;
                        Edge<String, Integer> newEdge = new Edge<>(destinationVertex, w, currentEdge);
                        sourceVertex.firstEdge = newEdge;
                        sourceVertex.outdeg++;
                        destinationVertex.indeg++;
                        return true;
                    }
                    destinationVertex = destinationVertex.nextVertex;
                }
            }
            sourceVertex = sourceVertex.nextVertex;
        }
        return false;
    }

    public boolean hasEdge(String source, String destination) {
        if (head == null)
            return false;
        if (!hasVertex(source) || !hasVertex(destination))
            return false;
        Task<String, Integer> sourceVertex = head;
        while (sourceVertex != null) {
            if (sourceVertex.vertexInfo.equals(source)) {
                Edge<String, Integer> currentEdge = sourceVertex.firstEdge;
                while (currentEdge != null) {
                    if (currentEdge.toVertex.vertexInfo.equals(destination))
                        return true;
                    currentEdge = currentEdge.nextEdge;
                }
            }
            sourceVertex = sourceVertex.nextVertex;
        }
        return false;
    }

    public Integer getEdgeWeight(String source, String destination) {
        Integer notFound = null;
        if (head == null)
            return notFound;
        if (!hasVertex(source) || !hasVertex(destination))
            return notFound;
        Task<String, Integer> sourceVertex = head;
        while (sourceVertex != null) {
            if (sourceVertex.vertexInfo.equals(source)) {
                Edge<String, Integer> currentEdge = sourceVertex.firstEdge;
                while (currentEdge != null) {
                    if (currentEdge.toVertex.vertexInfo.equals(destination))
                        return currentEdge.weight;
                    currentEdge = currentEdge.nextEdge;
                }
            }
            sourceVertex = sourceVertex.nextVertex;
        }
        return notFound;
    }

    public ArrayList<String> getNeighbours(String v) {
        if (!hasVertex(v))
            return null;
        ArrayList<String> list = new ArrayList<>();
        Task<String, Integer> temp = head;
        while (temp != null) {
            if (temp.vertexInfo.equals(v)) {
                Edge<String, Integer> currentEdge = temp.firstEdge;
                while (currentEdge != null) {
                    list.add(currentEdge.toVertex.vertexInfo);
                    currentEdge = currentEdge.nextEdge;
                }
            }
            temp = temp.nextVertex;
        }
        return list;
    }

    public void printEdges() {
        Task<String, Integer> temp = head;
        while (temp != null) {
            System.out.print("# " + temp.vertexInfo + " : ");
            Edge<String, Integer> currentEdge = temp.firstEdge;
            while (currentEdge != null) {
                System.out.print("[" + temp.vertexInfo + "," + currentEdge.toVertex.vertexInfo + "] ");
                currentEdge = currentEdge.nextEdge;
            }
            System.out.println();
            temp = temp.nextVertex;
        }
    }

    public void readDAGFile(String dagFile) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(dagFile));
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(" ");
            if (parts[0].equals("JOB")) {
                String taskName = parts[1];
                String taskFile = parts[2];
                addVertex(taskName);
                Task<String, Integer> task = new Task<>(taskName, null);
                tasks.put(taskName, task);
                readSubFile(taskName, taskFile);
            } else if (parts[0].equals("PARENT")) {
                String parent = parts[1];
                String child = parts[3];
                addVertex(parent);
                addVertex(child);
                addEdge(parent, child, 1);
                tasks.get(parent).outdeg++;
                tasks.get(child).indeg++;
            }
        }
        br.close();
    }

    private void readSubFile(String taskName, String subFile) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(subFile));
        String line;
        while ((line = br.readLine()) != null) {
            if (line.startsWith("estimate_runtime")) {
                String[] parts = line.split("=");
                int estimatedRunTime = Integer.parseInt(parts[1].trim());
                tasks.get(taskName).setEstimatedRunTime(estimatedRunTime);
            }
        }
        br.close();
    }

    public void printTasksSortedByEstimatedRunTime() {
        tasks.values().stream()
                .sorted(Comparator.comparingInt(Task::getEstimatedRunTime))
                .forEach(System.out::println);
    }

    public List<Task<String, Integer>> findCriticalPath() {
        Map<Task<String, Integer>, Integer> dist = new HashMap<>();
        Map<Task<String, Integer>, Task<String, Integer>> prev = new HashMap<>();
        LinkedList<Task<String, Integer>> topoOrder = topologicalSort();

        for (Task<String, Integer> task : tasks.values()) {
            dist.put(task, Integer.MIN_VALUE);
            prev.put(task, null);
        }
        dist.put(topoOrder.get(0), 0);

        while (!topoOrder.isEmpty()) {
            Task<String, Integer> u = topoOrder.poll();
            if (dist.get(u) != Integer.MIN_VALUE) {
                Edge<String, Integer> edge = u.firstEdge;
                while (edge != null) {
                    Task<String, Integer> v = edge.toVertex;
                    int weight = u.estimatedRunTime;
                    if (dist.get(v) < dist.get(u) + weight) {
                        dist.put(v, dist.get(u) + weight);
                        prev.put(v, u);
                    }
                    edge = edge.nextEdge;
                }
            }
        }

        Task<String, Integer> endTask = Collections.max(tasks.values(), Comparator.comparingInt(dist::get));
        LinkedList<Task<String, Integer>> path = new LinkedList<>();
        while (endTask != null) {
            path.addFirst(endTask);
            endTask = prev.get(endTask);
        }
        return path;
    }

    private LinkedList<Task<String, Integer>> topologicalSort() {
        LinkedList<Task<String, Integer>> topoOrder = new LinkedList<>();
        Map<Task<String, Integer>, Boolean> visited = new HashMap<>();
        for (Task<String, Integer> task : tasks.values()) {
            visited.put(task, false);
        }
        for (Task<String, Integer> task : tasks.values()) {
            if (!visited.get(task)) {
                topologicalSortUtil(task, visited, topoOrder);
            }
        }
        return topoOrder;
    }

    private void topologicalSortUtil(Task<String, Integer> task, Map<Task<String, Integer>, Boolean> visited, LinkedList<Task<String, Integer>> topoOrder) {
        visited.put(task, true);
        Edge<String, Integer> edge = task.firstEdge;
        while (edge != null) {
            Task<String, Integer> neighbor = edge.toVertex;
            if (!visited.get(neighbor)) {
                topologicalSortUtil(neighbor, visited, topoOrder);
            }
            edge = edge.nextEdge;
        }
        topoOrder.addFirst(task);
    }
}
