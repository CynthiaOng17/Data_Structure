/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask;

/**
 *
 * @author User
 */
public class LabTask {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
