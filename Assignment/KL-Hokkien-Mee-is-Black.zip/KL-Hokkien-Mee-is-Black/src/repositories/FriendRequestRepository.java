/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repositories;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import models.FriendRequest;

public class FriendRequestRepository {
    private Connection connect() {
        Connection conn = null;
        String url = "jdbc:mysql://localhost:3306/ds_assignment?zeroDateTimeBehavior=CONVERT_TO_NULL"; // MySQL connection string
        String user = "root";
        String password = "Wdhjbhgq@17@MySQL";

        try {
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }

    public void sendFriendRequest(String sender, String receiver) {
        String sql = "INSERT INTO friend_requests(sender_username, receiver_username, status) VALUES(?,?, 'pending')";
        try (Connection conn = this.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, sender);
            pstmt.setString(2, receiver);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public List<FriendRequest> getFriendRequests(String receiver) {
        String sql = "SELECT * FROM friend_requests WHERE receiver_username = ? AND status = 'pending'";
        List<FriendRequest> friendRequests = new ArrayList<>();
        try (Connection conn = this.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, receiver);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                FriendRequest request = new FriendRequest(
                        rs.getInt("id"),
                        rs.getString("sender_username"),
                        rs.getString("receiver_username"),
                        rs.getString("status")
                );
                friendRequests.add(request);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return friendRequests;
    }

     public void updateFriendName(String senderUsername, String receiverUsername) {
    String updateQuery = "UPDATE student SET friend_name = ? WHERE student_username = ?";
    try (Connection conn = connect();
         PreparedStatement pstmt = conn.prepareStatement(updateQuery)) {
        pstmt.setString(1, senderUsername);
        pstmt.setString(2, receiverUsername);
        pstmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    }
     public void updateFriendRequestStatus(String senderUsername, String receiverUsername, String status) {
    String updateQuery = "UPDATE friend_requests SET status = ? WHERE sender_username = ? AND receiver_username = ?";
    try (Connection conn = connect();
         PreparedStatement pstmt = conn.prepareStatement(updateQuery)) {
        pstmt.setString(1, status);
        pstmt.setString(2, senderUsername);
        pstmt.setString(3, receiverUsername);
        pstmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

}
