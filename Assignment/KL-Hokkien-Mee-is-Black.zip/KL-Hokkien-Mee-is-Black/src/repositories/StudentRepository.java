package repositories;

import services.StudentService;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StudentRepository implements StudentService {
    private final String STUDENT_CSV_FILE_PATH = "C:\\Users\\User\\Downloads\\Student - Sheet1.csv";
    private Connection connection = null; // Assign null initially
    private static String loggedInUsername; // Simulated logged-in user

    // Constructor with Connection parameter
    public StudentRepository(Connection connection) {
        this.connection = connection;
    }

    // Default constructor
    public StudentRepository() {
        // Attempt to establish a new database connection
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.connection = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/ds_assignment?zeroDateTimeBehavior=CONVERT_TO_NULL", 
                "root", 
                "Wdhjbhgq@17@MySQL"
            );
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Handle connection failure gracefully
        }
    }



    @Override
    public boolean registerStudent(String email, String username, String password, String role, String parent, String coordinate, int totalPoints) {
    boolean registered = false;

    try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish a connection
        Connection con = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/ds_assignment?zeroDateTimeBehavior=CONVERT_TO_NULL",
            "root",
            "Wdhjbhgq@17@MySQL"
        );

        // SQL query to insert data into student table
        String query = "INSERT INTO student (student_username, total_points, friend_name, email, password, coordinate_X, coordinate_Y) VALUES (?, ?, ?, ?, ?, ?, ?)";

        PreparedStatement pst = con.prepareStatement(query);
        pst.setString(1, username);
        pst.setString(2, String.valueOf(totalPoints)); // Assuming totalPoints is an int
        pst.setNull(3, java.sql.Types.VARCHAR); // friend_name as NULL
        pst.setString(4, email);
        pst.setString(5, password); // Assuming password is already hashed

        // Extracting coordinates from the formatted string "( x , y )"
        String[] coordinates = coordinate.replace("(", "").replace(")", "").split(",");
        pst.setString(6, coordinates[0].trim()); // coordinate_X
        pst.setString(7, coordinates[1].trim()); // coordinate_Y

        int result = pst.executeUpdate();

        if (result > 0) {
            // Insert into relationship table
            String relationshipQuery = "INSERT INTO relationship (parent_username, child_username) VALUES (?, ?)";
            PreparedStatement relationshipPst = con.prepareStatement(relationshipQuery);
            relationshipPst.setString(1, parent);
            relationshipPst.setString(2, username);
            int relationshipResult = relationshipPst.executeUpdate();

            if (relationshipResult > 0) {
                registered = true;
            }
        }

        con.close();
    } catch (Exception e) {
        e.printStackTrace();
    }

    return registered;
}
    public boolean registerStudentCSV(String email, String username, String password, String role, String parent, String coordinate, int totalPoints) {
        // Implement CSV writing logic to add a new educator
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(STUDENT_CSV_FILE_PATH, true))) {
            writer.write(email+ "," +username + "," + password + "," + role +","+parent+","+ coordinate + ","+totalPoints+"\n");
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }


    @Override
    public boolean getLogin(String username, String password) {
        try (BufferedReader reader = new BufferedReader(new FileReader(STUDENT_CSV_FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 7) {
                    String csvUsername = parts[1];
                    String csvPassword = parts[2];
                    if (username.equals(csvUsername) && password.equals(csvPassword)) {
                        loggedInUsername = username; // Set logged-in user
                        return true;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean checkAnswer(String theme, String question, String userAnswer) {
        String query = "SELECT correct_answer FROM quiz WHERE theme = ? AND question = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, theme);
            pstmt.setString(2, question);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String correctAnswer = rs.getString("correct_answer");
                return correctAnswer.equalsIgnoreCase(userAnswer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public String getQuestion(String theme) {
        String query = "SELECT question FROM quiz WHERE theme = ? ORDER BY RAND() LIMIT 1";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, theme);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getString("question");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
}


    @Override
    public int getTotalPoints(String studentUsername) {
        String query = "SELECT total_points FROM student WHERE student_username = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, studentUsername);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("total_points");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public void updateStudentPoints(String username, int pointsToAdd) {
        String query = "UPDATE student SET total_points = total_points + ? WHERE student_username = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, pointsToAdd);
            statement.setString(2, username);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String getLoggedInUsername() {
        return loggedInUsername; // Return the currently logged-in username
    }

    // Additional methods can be removed or commented out if not used
}
