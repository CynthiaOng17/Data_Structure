/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package models;


import java.util.List;

public class User {
    private String username;
    private String email;
    private String password;
    private Role role;
    private List<User> parents; 
    private List<User> children; 
    private String locationCoordinate;
    private int currentPoints;

    public User(String username, String email, Role role) {
        this.username = username;
        this.email = email;
        this.role = role;
    }
    public User(String username, String email, String password, Role role, String locationCoordinate) {
        this(username, email, role);
        this.password = password;
        this.locationCoordinate = locationCoordinate;
    }

    // Getters and setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }
}
