package services;

public interface StudentService {
    boolean registerStudent(String email, String username, String password, String role, String parent, String coordinate, int currentPoint);
    boolean getLogin(String username, String password);
    boolean checkAnswer(String theme, String question, String userAnswer);
    String getQuestion(String theme);
    int getTotalPoints(String studentUsername);
    void updateStudentPoints(String username, int pointsToAdd);
    String getLoggedInUsername(); // Add this method
}


