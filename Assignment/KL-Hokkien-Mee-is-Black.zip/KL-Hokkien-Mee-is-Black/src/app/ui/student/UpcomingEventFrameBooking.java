/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package app.ui.student;

import app.ui.*;
import javax.swing.JOptionPane;
import java.sql.*;
import models.Role;
import session.SessionManager;

public class UpcomingEventFrameBooking extends javax.swing.JFrame {



    public UpcomingEventFrameBooking() {
        initComponents();
        loadEventData(); 
    }
     

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        eventLabel = new javax.swing.JLabel();
        book1 = new javax.swing.JButton();
        book2 = new javax.swing.JButton();
        book3 = new javax.swing.JButton();
        homeButton1 = new javax.swing.JButton();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(480, 360));

        jPanel1.setMaximumSize(new java.awt.Dimension(4000, 3000));
        jPanel1.setMinimumSize(new java.awt.Dimension(4000, 3000));
        jPanel1.setName(""); // NOI18N
        jPanel1.setPreferredSize(new java.awt.Dimension(4000, 3000));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("SansSerif", 1, 54)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Upcoming Event");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 610, 125));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255, 80));

        eventLabel.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        eventLabel.setText("jLabel2");
        eventLabel.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        book1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        book1.setText("1");
        book1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                book1ActionPerformed(evt);
            }
        });

        book2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        book2.setText("2");
        book2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                book2ActionPerformed(evt);
            }
        });

        book3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        book3.setText("3");
        book3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                book3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(eventLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 862, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(book1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(book2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(book3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(eventLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 510, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(book1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(129, 129, 129)
                .addComponent(book2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(book3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(102, 102, 102))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 190, 930, 510));

        homeButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/app/ui/homeButton1.jpg"))); // NOI18N
        homeButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(homeButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1360, 740, 50, 40));

        background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/app/ui/upcoming1.jpg"))); // NOI18N
        jPanel1.add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -180, 1760, 1260));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 2257, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 557, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 2491, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void book1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_book1ActionPerformed
        // TODO add your handling code here:
        bookEvent(0);
        
    }//GEN-LAST:event_book1ActionPerformed

    private void homeButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeButton1ActionPerformed
        // TODO add your handling code here:
        StudentHomeFrame studentHomeFrame = new StudentHomeFrame();
        studentHomeFrame.setVisible(true);
        dispose();
    }//GEN-LAST:event_homeButton1ActionPerformed

    private void book2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_book2ActionPerformed
        // TODO add your handling code here:
        bookEvent(1);
    }//GEN-LAST:event_book2ActionPerformed

    private void book3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_book3ActionPerformed
        // TODO add your handling code here:
        bookEvent(2);
    }//GEN-LAST:event_book3ActionPerformed

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/ds_assignment?zeroDateTimeBehavior=CONVERT_TO_NULL",
                "root",
                "Wdhjbhgq@17@MySQL"
        );
    }

   private void loadEventData() {
    String query = "SELECT title, description, venue, date, time FROM event WHERE date > CURDATE() ORDER BY date, time LIMIT 3";
    try (Connection con = getConnection();
         PreparedStatement pst = con.prepareStatement(query);
         ResultSet rs = pst.executeQuery()) {

        boolean eventsFound = false;
        StringBuilder events = new StringBuilder("<html>");
        while (rs.next()) {
            String title = rs.getString("title");
            String description = rs.getString("description");
            String venue = rs.getString("venue");
            Date date = rs.getDate("date");
            Time time = rs.getTime("time");

            events.append("<b>Event:</b> ").append(title)
                  .append("<br><b>Description:</b> ").append(description)
                  .append("<br><b>Venue:</b> ").append(venue)
                  .append("<br><b>Date:</b> ").append(date)
                  .append("<br><b>Time:</b> ").append(time)
                  .append("<br><br>");
            
            eventsFound = true;
        }
        events.append("</html>");

        if (eventsFound) {
            eventLabel.setText(events.toString());
        } else {
            eventLabel.setText("No upcoming events.");
        }

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "An error occurred while fetching events.");
    }
}
private void bookEvent(int offset) {
          String query = "SELECT venue, date FROM event WHERE date >= CURDATE() ORDER BY date, time LIMIT 1 OFFSET " + offset;
        try (Connection con = getConnection();
             PreparedStatement pst = con.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {

            if (rs.next()) {
                String venue = rs.getString("venue");
                Date eventDate = rs.getDate("date");
                String currentUser = SessionManager.getUsername();

                // Check if the user already has a booking on this date
                String checkQuery = "SELECT COUNT(*) FROM bookings WHERE child = ? AND booking_date = ?";
                try (PreparedStatement checkPst = con.prepareStatement(checkQuery)) {
                    checkPst.setString(1, currentUser);
                    checkPst.setDate(2, eventDate);
                    ResultSet checkRs = checkPst.executeQuery();
                    if (checkRs.next() && checkRs.getInt(1) > 0) {
                        JOptionPane.showMessageDialog(this, "You already have a booking on this date.");
                        return;
                    }
                }

                // Insert booking details into bookings table
                String insertQuery = "INSERT INTO bookings (destination_name, parent, child, booking_date) VALUES (?, ?, ?, ?)";
                try (PreparedStatement insertPst = con.prepareStatement(insertQuery)) {
                    insertPst.setString(1, venue);
                    insertPst.setString(2, ""); // Providing a dummy value for parent
                    insertPst.setString(3, currentUser);
                    insertPst.setDate(4, eventDate);
                    insertPst.executeUpdate();

                    // Update total points in the student table
                    String updatePointsQuery = "UPDATE student SET total_points = total_points + 5 WHERE student_username = ?";
                    try (PreparedStatement updatePst = con.prepareStatement(updatePointsQuery)) {
                        updatePst.setString(1, currentUser);
                        updatePst.executeUpdate();
                    }

                    JOptionPane.showMessageDialog(this, "Event booked successfully and 5 points updated!");
                }
            } else {
                JOptionPane.showMessageDialog(this, "No upcoming events available to book.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "An error occurred while booking the event.");
        }
    }

    
    
    public static void main(String args[]) {
        

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpcomingEventFrameBooking().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel background;
    private javax.swing.JButton book1;
    private javax.swing.JButton book2;
    private javax.swing.JButton book3;
    private javax.swing.JLabel eventLabel;
    private javax.swing.JButton homeButton1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
