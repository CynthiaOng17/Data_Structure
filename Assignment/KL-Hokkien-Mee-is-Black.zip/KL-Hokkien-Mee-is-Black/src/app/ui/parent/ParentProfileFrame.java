/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package app.ui.parent;
import java.sql.*;
import javax.swing.JOptionPane;
import models.Role;
import models.User;
import session.SessionManager;

/**
 *
 * @author x
 */
public class ParentProfileFrame extends javax.swing.JFrame {

    /**
     * Creates new form Login
     */
       // Declare UI components for username and children labels

    // Declare repositories

    /**
     * Creates new form Login
     */
    public void Connect(String parentUsername) {
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/ds_assignment?zeroDateTimeBehavior=CONVERT_TO_NULL", 
            "root", 
            "Wdhjbhgq@17@MySQL"
        );
        
        // Use PreparedStatement to prevent SQL injection
        String parentQuery = "SELECT parent.parent_username, parent.email, parent.coordinate_X, parent.coordinate_Y, relationship.child_username " +
                             "FROM parent " +
                             "JOIN relationship ON parent.parent_username = relationship.parent_username " +
                             "WHERE parent.parent_username = ?";
//        String parentQuery = "SELECT p.parent_username, p.email AS parent_email, p.coordinate_X AS parent_coordinate_X, p.coordinate_Y AS parent_coordinate_Y, " +
//                     "s.student_username, s.email AS student_email, s.password AS student_password, s.coordinate_X AS student_coordinate_X, s.coordinate_Y AS student_coordinate_Y " +
//                     "FROM parent p " +
//                     "JOIN relationship r ON p.parent_username = r.parent_username " +
//                     "JOIN student s ON r.child_username = s.student_username " +
//                     "WHERE p.parent_username = ?";

        PreparedStatement parentPst = con.prepareStatement(parentQuery);
        parentPst.setString(1, parentUsername);
        ResultSet parentRs = parentPst.executeQuery();

        // Clear any previous text in the labels
        username.setText("");
        children.setText("");
        email.setText("");
        locationCoordinate.setText("");
        bookingsMadeLabel.setText(""); // Clear the booking label

        // Variables to store parent details
        String parentName = "";
        String parentEmail = "";
        double coordinateX = 0;
        double coordinateY = 0;
        StringBuilder childNames = new StringBuilder();

        // Counter for numbering the children
        int childCount = 1;

        // Loop through the result set for parent details
        while (parentRs.next()) {
            // Get parent username, email, coordinates, and child username
            parentName = parentRs.getString("parent_username"); // Corrected column name
            parentEmail = parentRs.getString("email"); // Corrected column name
            coordinateX = parentRs.getDouble("coordinate_X"); // Corrected column name
            coordinateY = parentRs.getDouble("coordinate_Y"); // Corrected column name
            String childName = parentRs.getString("child_username");

            // Append child number and name with newline separator
            childNames.append(childCount).append(") ").append(childName).append(" ");
            // Increment child counter
            childCount++;
        }

        // Set the text of the labels with parent and numbered child usernames
        username.setText(parentName);
        children.setText(childNames.toString()); // Convert StringBuilder to String
        email.setText(parentEmail);
        locationCoordinate.setText("(" + coordinateX + ", " + coordinateY + ")");

        // Now retrieve booking details for the given parent username
        String bookingQuery = "SELECT destination_name, child, booking_date FROM bookings WHERE parent = ?";
        PreparedStatement bookingPst = con.prepareStatement(bookingQuery);
        bookingPst.setString(1, parentUsername);
        ResultSet bookingRs = bookingPst.executeQuery();

        // Append booking details to the bookingMadeLabel
        StringBuilder bookingDetails = new StringBuilder();
        while (bookingRs.next()) {
        String destinationName = bookingRs.getString("destination_name");
        String childName = bookingRs.getString("child");
        String bookingDate = bookingRs.getString("booking_date");

        bookingDetails.append("Destination: ").append(destinationName)
                      .append(", Child: ").append(childName)
                      .append(", Date: ").append(bookingDate)
                      .append("<br>"); // Use <br> for HTML line break
}
bookingsMadeLabel.setText("<html>" + bookingDetails.toString() + "</html>");


        con.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}


    public ParentProfileFrame() {
        initComponents();
        Connect(SessionManager.getUsername());

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        locationCoordinate = new javax.swing.JLabel();
        username = new javax.swing.JLabel();
        email = new javax.swing.JLabel();
        children = new javax.swing.JLabel();
        bookingsMadeLabel = new javax.swing.JLabel();
        homeButton = new javax.swing.JButton();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(480, 360));

        jPanel1.setMaximumSize(new java.awt.Dimension(4000, 3000));
        jPanel1.setMinimumSize(new java.awt.Dimension(4000, 3000));
        jPanel1.setName(""); // NOI18N
        jPanel1.setPreferredSize(new java.awt.Dimension(4000, 3000));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("SansSerif", 1, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Profile");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 50, -1, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        jLabel8.setText("Location Coordinate:");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 500, -1, -1));

        jLabel14.setBackground(new java.awt.Color(204, 204, 0));
        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel14.setText("Parent");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, -1, -1));

        jLabel4.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        jLabel4.setText("Username:");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, -1, -1));

        jLabel5.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        jLabel5.setText("Email:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, -1, -1));

        jLabel15.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        jLabel15.setText("Children:");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, -1, -1));

        jLabel7.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        jLabel7.setText("Bookings made:");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 330, -1, -1));

        locationCoordinate.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        locationCoordinate.setText("1");
        jPanel2.add(locationCoordinate, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 490, 450, 50));

        username.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        username.setText("1");
        jPanel2.add(username, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 80, 240, 50));

        email.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        email.setText("1");
        email.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                emailAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jPanel2.add(email, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 150, 440, 50));

        children.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        children.setText("1");
        jPanel2.add(children, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 200, 490, 100));

        bookingsMadeLabel.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        bookingsMadeLabel.setText("1");
        bookingsMadeLabel.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel2.add(bookingsMadeLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 320, 670, 170));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 120, 910, 580));

        homeButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/app/ui/homeButton1.jpg"))); // NOI18N
        homeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeButtonActionPerformed(evt);
            }
        });
        jPanel1.add(homeButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(1360, 740, 50, 40));

        background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/app/ui/profileB.jpg"))); // NOI18N
        jPanel1.add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -180, 1760, 1260));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 2257, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 557, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 2491, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void emailAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_emailAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_emailAncestorAdded

    private void homeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeButtonActionPerformed
        // TODO add your handling code here:
        Role currentRole = SessionManager.getCurrentUserRole();
        if (currentRole == Role.EDUCATOR) {
            new app.ui.educator.EducatorHomeFrame().setVisible(true);
        } else if (currentRole == Role.PARENT) {
            new app.ui.parent.ParentHomeFrame().setVisible(true);
        } else if (currentRole == Role.STUDENT) {
            new app.ui.student.StudentHomeFrame().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Access Denied: Invalid Role.");
        }
        this.setVisible(false);
        this.dispose();
    }//GEN-LAST:event_homeButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ParentProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ParentProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ParentProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ParentProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ParentProfileFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel background;
    private javax.swing.JLabel bookingsMadeLabel;
    private javax.swing.JLabel children;
    private javax.swing.JLabel email;
    private javax.swing.JButton homeButton;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel locationCoordinate;
    private javax.swing.JLabel username;
    // End of variables declaration//GEN-END:variables
}
