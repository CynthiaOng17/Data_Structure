/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package app.ui;

import javax.swing.JOptionPane;
import java.sql.*;
import models.Role;
import session.SessionManager;

public class UpcomingEventFrame extends javax.swing.JFrame {



    public UpcomingEventFrame() {
        initComponents();
        loadEventData(); 
    }
     

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        eventLabel = new javax.swing.JLabel();
        homeButton = new javax.swing.JButton();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(480, 360));

        jPanel1.setMaximumSize(new java.awt.Dimension(4000, 3000));
        jPanel1.setMinimumSize(new java.awt.Dimension(4000, 3000));
        jPanel1.setName(""); // NOI18N
        jPanel1.setPreferredSize(new java.awt.Dimension(4000, 3000));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("SansSerif", 1, 54)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Upcoming Event");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 610, 125));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255, 80));

        eventLabel.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        eventLabel.setText("jLabel2");
        eventLabel.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(eventLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 924, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(eventLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 510, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 190, 930, 510));

        homeButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/app/ui/homeButton1.jpg"))); // NOI18N
        homeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeButtonActionPerformed(evt);
            }
        });
        jPanel1.add(homeButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(1360, 740, 50, 40));

        background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/app/ui/upcoming1.jpg"))); // NOI18N
        jPanel1.add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -180, 1760, 1260));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 2257, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 557, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 2491, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void homeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeButtonActionPerformed
        // TODO add your handling code here:
        Role currentRole = SessionManager.getCurrentUserRole();
        if (currentRole == Role.EDUCATOR) {
            new app.ui.educator.EducatorHomeFrame().setVisible(true);
        } else if (currentRole == Role.PARENT) {
            new app.ui.parent.ParentHomeFrame().setVisible(true);
        } else if (currentRole == Role.STUDENT) {
            new app.ui.student.StudentHomeFrame().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Access Denied: Invalid Role.");
        }
        this.setVisible(false);
        this.dispose();
    }//GEN-LAST:event_homeButtonActionPerformed

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/ds_assignment?zeroDateTimeBehavior=CONVERT_TO_NULL",
                "root",
                "Wdhjbhgq@17@MySQL"
        );
    }

   private void loadEventData() {
    String query = "SELECT title, description, venue, date, time FROM event WHERE date >= CURDATE() ORDER BY date, time LIMIT 3";
    try (Connection con = getConnection();
         PreparedStatement pst = con.prepareStatement(query);
         ResultSet rs = pst.executeQuery()) {

        boolean eventsFound = false;
        StringBuilder events = new StringBuilder("<html>");
        while (rs.next()) {
            String title = rs.getString("title");
            String description = rs.getString("description");
            String venue = rs.getString("venue");
            Date date = rs.getDate("date");
            Time time = rs.getTime("time");

            events.append("<b>Event:</b> ").append(title)
                  .append("<br><b>Description:</b> ").append(description)
                  .append("<br><b>Venue:</b> ").append(venue)
                  .append("<br><b>Date:</b> ").append(date)
                  .append("<br><b>Time:</b> ").append(time)
                  .append("<br><br>");
            
            eventsFound = true;
        }
        events.append("</html>");

        if (eventsFound) {
            eventLabel.setText(events.toString());
        } else {
            eventLabel.setText("No upcoming events.");
        }

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "An error occurred while fetching events.");
    }
}

    
    
    public static void main(String args[]) {
        

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpcomingEventFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel background;
    private javax.swing.JLabel eventLabel;
    private javax.swing.JButton homeButton;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
