/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package session;

/**
 *
 * @author User
 */

import models.User;
import models.Role;

public class SessionManager {
    private static User currentUser;
    private static String username;
    private static Role role;

    public static void login(User user) {
        currentUser = user;
        username = user.getUsername();
        role = user.getRole();
    }

    public static void logout() {
        currentUser = null;
        username = null;
        role = null;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static Role getCurrentUserRole() {
        return role;
    }

    public static String getUsername() {
        return username;
    }

    public static void setUsername(String username) {
        SessionManager.username = username;
    }
}


